#ifdef PACDRIVE_EXPORTS
#define PACDRIVE_API __declspec(dllexport)
#else
#define PACDRIVE_API __declspec(dllimport)
#endif


PACDRIVE_API int __stdcall PacInitialize();
PACDRIVE_API void __stdcall PacShutdown();
PACDRIVE_API bool __stdcall PacSetLEDStates(int id, USHORT data);
PACDRIVE_API int __stdcall PacGetVendorId(int id);
PACDRIVE_API int __stdcall PacGetProductId(int id);
PACDRIVE_API int __stdcall PacGetVersionNumber(int id);
PACDRIVE_API void __stdcall PacGetVendorName(int id, PCHAR sVendorName);
PACDRIVE_API void __stdcall PacGetProductName(int id, PCHAR sProductName);
PACDRIVE_API void __stdcall PacGetSerialNumber(int id, PCHAR sSerialNumber);
PACDRIVE_API void __stdcall PacGetDevicePath(int id, PCHAR sDevicePath);
PACDRIVE_API bool __stdcall PacProgramUHid(int id, PCHAR sFilePath);
PACDRIVE_API bool __stdcall PacSetLEDState(int id, int port, bool state);


