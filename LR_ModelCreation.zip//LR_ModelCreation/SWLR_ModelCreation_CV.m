%% STEP-WISE LOGISTIC REGRESSION
    % This code loads a matrix containing all the data sets for the worm
    % strains studied in this paper. Data is contained in matrix
    % 'WZ-raw.mat'. Each piece of data used in the code is explained in
    % its first appearance.
    % 'WZ-raw.mat' is a structure containing the several fileds, the
    % following fields are relevant for this code:
    % each worm strain:
        % rnd: round of imaging that each strain belongs to, wildtype
        % comparison for first round is located in index #18, wildtype
        % comparison for second round is located in index #43
        % stats: a matrix of all the data for that strain, rows are
        % individual worms, columns represent different features (1 to 76,
        % see supplemental for information)
        % class: 1 if animal is a mutant, 0 if it is wildtype
        % Group: the group represented in Figure 3a (known visually
        % identifiable mutants, known ventral mislocalization mutants, 
        % known not-visually identifiable mutants, mutants isolated in this
        % screen)
        
    % Written by Adriana San-Miguel, latest update: 2016/04/14
%% 1) CONSTRUCTION OF MODELS
%%Load Data
clear
load('WS-raw.mat')

%% z-scores
[mu1,si1]=normfit(data(15).stats);
[mu2,si2]=normfit(data(43).stats);
%% STEPWISE LOGISTIC REGRESSION MODEL CONSTRUCTION & FEATURE SELECTION

for mut=1:length(data)
    
    % Select wildype data set to compare to:
    if strcmp(data(mut).rnd,'R2')
        wti=43; %index for wildtype population if mutant comes from second imaging round
        cMWParameters.mu=mu2;cMWParameters.si=si2;
    else
        wti=15; %index for wildtype population if mutant comes from first imaging round
        cMWParameters.mu=mu1;cMWParameters.si=si1;
    end
    
    % Turn off warnings for null models 
    warning('off','stats:glmfit:IllConditioned');
    warning('off','stats:glmfit:PerfectSeparation');
    warning('off','stats:glmfit:IterationLimit');
    
    clear lin phat Xdes Xt mutant %clear variables for loop

    % Create a matrix for model fitting, X=variables, Y=binary output
    Xa=vertcat(data(wti).stats(:,:),data(mut).stats(:,:));
    Ya=vertcat(data(wti).class(:,:),data(mut).class(:,:));
    Xa=(Xa - repmat(cMWParameters.mu,size(Xa,1),1))./repmat(cMWParameters.si,size(Xa,1),1);
    Xa(isnan(Xa))=0;

    f=[1:76]; % Feature set
    removed=0;% Features removed so far
    
    %--STEP(0):FORWARD SELECTION
        k=f; % Features to include
        X=(Xa(:,k));    Y=(Ya(:));   
        % Model constructed with only a constant (i.e., no variables)
        [b0, dev0, stats0] = glmfit(zeros(size(Y)),Y,'binomial','link','logit');
        initdev=dev0;
        
        clear Devchange k G pval
        
        % Create models with a single variable, calculare deviance and pval
        for i=1:length(f)
            k=f(i);        X=(Xa(:,k));        Y=(Ya(:));
            [b, dev, stats]=glmfit(X,Y, 'binomial','link','logit','constant','on');
            G(i)=dev0 - dev;
            pval(i)=1-chi2cdf(G(i),1);
        end
        
        % Select feature whose model has lowest pval or maximum deviance
        % change, if pval is too small
        [c val]=min(pval);
        
        % Threshold for adding a variable is p=0.05
        n=1;
        if c<0.05/n;
            if c==0
                [cc val]=max(G);
            end
            
            forfeat=f(val);% Forfeat contains the variable set thus far
            forfeatg=dev0-G(val); %model deviance
            forfeatgd=G(val); %deviance difference against null model
        end

     %--STEP(1):2nd FORWARD SELECTION
        disp('2nd forward selection')
        X0=Xa(:,forfeat);   
        [bs0, devs0, statss0] = glmfit(X0,Y, 'binomial','link','logit','constant','on');
        
        clear Devchange k G pval
        for i=1:length(f)
            k=[f(i) forfeat];        X=(Xa(:,k));        Y=(Ya(:));
            [b, dev, stats]=glmfit(X,Y, 'binomial','link','logit','constant','on');
            G(i)=devs0 - dev;
            pval(i)=1-chi2cdf(G(i),1);
        end

        [c val]=min(pval);
        if c<0.05/n
            if c==0
                [cc val]=max(G);
            end
            forfeat=[forfeat f(val)];
            forfeatg=[forfeatg devs0-G(val)]; %deviance 
            forfeatgd=[forfeatgd G(val)]; % deviance change
        end
    
    % STEP(2): BACKWARD & FORWARD SELECTION

    cont1=0;
    cont2=length(forfeat);
    while cont2>cont1
        cont1=cont2;
        X1=Xa(:,forfeat);   
        [bs1, devs1, statss1] = glmfit(X1,Y, 'binomial','link','logit','constant','on');
        
        clear  k pval G
        for i=1:length(forfeat)

            k=forfeat;          k(i)=[];
            X=(Xa(:,k));        Y=(Ya(:));
            [b, dev, stats]=glmfit(X,Y, 'binomial','link','logit','constant','on');
            G(i)=devs1 - dev;
            pval(i)=1-chi2cdf(G(i),1);
        end

        [c val]=min(pval);
        if c<0.1/n
            if c==0
                [cc val]=max(G);
            end
            forfeat(val)=[];
            forfeatg(val)=[];
            forfeatgd(val)=[];
            removed=removed+1;
        end
        X1=Xa(:,forfeat);   
        [bs1, devs1, statss1] = glmfit(X1,Y, 'binomial','link','logit','constant','on');
        clear  k pval
        for i=1:length(f)
            k=[f(i) forfeat];        X=(Xa(:,k));        Y=(Ya(:));
            [b, dev, stats]=glmfit(X,Y, 'binomial','link','logit','constant','on');
            G(i)=devs1 - dev;
            pval(i)=1-chi2cdf(G(i),1);
        end
        [c val]=min(pval);
        if c<0.05/n
            if c==0
                [cc val]=max(G);
            end
            forfeat=[forfeat f(val)];
            forfeatg=[forfeatg devs1-G(val)];%deviance 
            forfeatgd=[forfeatgd G(val)];%deviance change
        end
        cont2=length(forfeat);
    end
    disp(strcat('STEPWISE REGRESSION DONE worm:',int2str(mut)));

    k=[forfeat];        X=(Xa(:,k));        Y=(Ya(:));
    % Turn on warnings for final model
    warning('on','stats:glmfit:IllConditioned');
    warning('on','stats:glmfit:PerfectSeparation');
    warning('on','stats:glmfit:IterationLimit');
    [b, dev, stats]=glmfit(X,Y, 'binomial','link','logit','constant','on');
    data(mut).bs1=b;
    data(mut).features=forfeat;
    data(mut).dev=forfeatg;
    data(mut).dev_change=forfeatgd;    
end

%% Cross-validation model performance
indices=[1:14,16:42,44];
for mutc=1:length(indices)
    mut=indices(mutc);
    if strcmp(data(mut).rnd,'R2')
        wti=43; %index for wildtype population if mutant comes from second imaging round
        cMWParameters.mu=mu2;cMWParameters.si=si2;
    else
        wti=15; %index for wildtype population if mutant comes from first imaging round
        cMWParameters.mu=mu1;cMWParameters.si=si1;
    end
 
    clear X Xf b lin Y phat Xdes Xt mutant

    Xa=vertcat(data(wti).stats(:,:),data(mut).stats(:,:));
    Ya=vertcat(data(wti).class(:,:),data(mut).class(:,:));
    
    % Normalize data (according to WT ranges)
    Xa=(Xa - repmat(cMWParameters.mu,size(Xa,1),1))./repmat(cMWParameters.si,size(Xa,1),1);
    Xa(isnan(Xa))=0;
    f=data(mut).features;
    CVI=crossvalind('Kfold', length(Ya), 5);
    
    for j=1:5 % j = cross-validation round
        
        clear X1 Xdes 
        Y=Ya(CVI~=j);
        X1=Xa((CVI~=j),f);   Xdes=[ones(size(Y)) X1];
        warning('on','stats:glmfit:IllConditioned');
        warning('on','stats:glmfit:PerfectSeparation');
        warning('on','stats:glmfit:IterationLimit');
        [b, dev, stats]=glmfit(X1,Y, 'binomial','link','logit','constant','on');  
        warning('off','stats:glmfit:IllConditioned');
        warning('off','stats:glmfit:PerfectSeparation');
        warning('off','stats:glmfit:IterationLimit');
        [b0, dev0, stats0] = glmfit(zeros(size(Y)),Y,'binomial','link','logit');
        
        Y=Ya(CVI==j);
        X1=Xa((CVI==j),f);   Xdes=[ones(size(Y)) X1];
        labels=Y;
        lin = Xdes * b ;
        lin(lin>700)=700;
        phat=exp(lin)./(1 + exp(lin));
    
        % LR ratio & R2s
        loglik = sum( Y .* lin - log( 1 + exp(lin) ));
        loglik0 = sum( Y .* b0(1) - log(1 + exp(b0(1))) ); 
        LR(mut,j)=-2*loglik0+2*loglik;
        mcfadden(mut,j) = -2*(loglik0-loglik)/(-2*loglik0);
        effron(mut,j)=1-nansum((Y-phat).^2)/nansum((Y-sum(Y)/length(Y)).^2);
    
        % Roc curve
        [FP,TP,T,AUC] = perfcurve(labels,phat,1);
        auc(mut,j)=AUC;
        
        pmt=phat(logical(labels));
        pwt=phat(~logical(labels));
        TP(mut,j)=sum(pmt>0.5)/length(pmt)*100; %sensitivity
        TN(mut,j)=sum(pwt<0.5)/length(pwt)*100; %specificity
        AC(mut,j)=(sum(pmt>0.5)+sum(pwt<0.5))/length(phat); %accuracy
    end
    j=6;
    clear X1 Xdes 
    
        Y=Ya(:);
        X1=Xa(:,f);   Xdes=[ones(size(Y)) X1];
        labels=Y;

        warning('on','stats:glmfit:IllConditioned');
        warning('on','stats:glmfit:PerfectSeparation');
        warning('on','stats:glmfit:IterationLimit');
        [b, dev, stats]=glmfit(X1,Y, 'binomial','link','logit','constant','on');  
        lin = Xdes * b ;
        lin(lin>700)=700;
        phat=exp(lin)./(1 + exp(lin));
    
        % LR ratio & R2s
        
        loglik = sum( Y .* lin - log( 1 + exp(lin) ));
        warning('off','stats:glmfit:IllConditioned');
        warning('off','stats:glmfit:PerfectSeparation');
        warning('off','stats:glmfit:IterationLimit');
        [b0, dev0, stats0] = glmfit(zeros(size(Y)),Y,'binomial','link','logit');
        loglik0 = sum( Y .* b0(1) - log(1 + exp(b0(1))) ); 
        LR(mut,j)=-2*loglik0+2*loglik;
        mcfadden(mut,j) = -2*(loglik0-loglik)/(-2*loglik0);
        effron(mut,j)=1-nansum((Y-phat).^2)/nansum((Y-sum(Y)/length(Y)).^2);
        
    
    
        % Roc curve
        [FP,TP,T,AUC] = perfcurve(labels,phat,1);
        auc(mut,j)=AUC;
        
        % odds ratio at 50%
        [difs,idx] = min(abs(T-0.5)); %index of closest value
        FPf=FP(idx);
        TPf=TP(idx);
        FNf=1-TPf; %lenient
        TNf=1-FPf; %lenient
        ORf=(TNf*TPf)/(FPf*FNf);
        OR(mut,j)=ORf;
        data(mut).aucCV=auc(mut,1:5);
        data(mut).LRCV=LR(mut,1:5);
        data(mut).auc=auc(mut,6);
        data(mut).LR=LR(mut,6);
        
        pmt=phat(logical(labels));
        pwt=phat(~(logical(labels)));
        TP(mut,j)=sum(pmt>0.5)/length(pmt)*100; %sensitivity
        TN(mut,j)=sum(pwt<0.5)/length(pwt)*100; %specificity
        AC(mut,j)=(sum(pmt>0.5)+sum(pwt<0.5))/length(phat); %accuracy
        
        data(mut).ACCcv=AC(mut,1:5);
        data(mut).ACC=AC(mut,6);
end

%%
save('WholeSet_SWLR.mat','data')
