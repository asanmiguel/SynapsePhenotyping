%%% EXTRACT REQUIRED STATS

function all=extractpopulationfeatures(allstats)
    stats=[];
    for i=1:length(allstats)
        if isempty(allstats(i).stats)
            stats(i,1:76)=NaN;
            stats_ai(i,1:18)=NaN;
        else
            try
                [stats(i,:),stats_ai(i,:)]=phenotypicfeatures_n(allstats(i));
            catch
                stats(i,1:76)=NaN;
                stats_ai(i,1:18)=NaN;
            end    
        end
    end

    means=nanmean(stats);
    standards=nanstd(stats);
    stdstd=standards./means;

    for i=1:length(stats)
        filenum(i)=i;
    end

    all.allstats=allstats;
    all.statsnan=stats;
    all.means=means;
    all.standards=standards;
    all.stdstd=stdstd;
    all.statsainan=stats_ai;
    erase=isnan(stats(:,1));
    stats(erase,:)=[];
    filenum(erase)=[];
    all.stats=stats;
    all.filenum=filenum;
    stats_ai(erase,:)=[];
    all.statsai=stats_ai;
    z=[];
    z(:,1)=all.means;
    z(:,2)=all.standards;
    z(:,3)=all.stdstd;
    z(:,4)=size(stats,1);
    all.summary=z;
end