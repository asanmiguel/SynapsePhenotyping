function [analyze_worm,or,ecc]=analyze_wormorientation(img,analysis_step,st_angle)
    
%%1=YES
%%0=NO
%%2=RE-ANALYZE

    threshold_eccentricity=0.75;
    threshold_snap_pos=2.5;
    threshold_snap_neg=1.5;
    threshold_stack_pos=1;
    
    img=double(mat2gray(img));
    J=imadjust(img);
    level=graythresh(J);
    
% BLOB: ECCENTRICITY FOR CURLED-UP ANIMALS
    imbw2=im2bw(J,level*0.85);
    se2=strel('disk',20);
    imbw2 = imclose(imbw2,se2);
    blob=regionprops(imbw2,'Area','PixelIdxList');
    areas=[];pospixels=[];
    for k=1:length(blob)
        areas(k)=blob(k).Area;
    end
    [t ttb]=max(areas);
    imbw2=zeros(size(imbw2));
    pospixels=blob(ttb).PixelIdxList;
    imbw2(pospixels)=1;

    test=regionprops(imbw2,'PixelList');
    firstx=test.PixelList(1,1);
    lastx=test.PixelList(length(test.PixelList),1);
    totalx=lastx-firstx;

    if totalx>500
        erasefrom=lastx-round(totalx/2);
        endat=lastx;
        imbw2(:,erasefrom:endat)=0;
    end

    blobtt=regionprops(imbw2,'Eccentricity');
    ecc=blobtt.Eccentricity;
    
    if analysis_step==1
        
        if ecc<threshold_eccentricity
            analyze_worm=0;
            or=NaN;
        else
            % GUT FROM SNAPSHOT
            imbw=im2bw(J,level*1.5);
            se=strel('disk',10);
            imbw = imclose(imbw,se);
            test=regionprops(imbw,'Area','PixelIdxList','MajorAxisLength');
            areas=[];axis_length=[];pospixels=[];
            for k=1:length(test)
                areas(k)=test(k).Area;
                axis_length(k)=test(k).MajorAxisLength;
            end
            imbw=zeros(size(imbw));
            [t tt]=max(axis_length);
            pospixels=test(tt).PixelIdxList;
            imbw(pospixels)=1;
            test=regionprops(imbw,'PixelList');
            firstx=test.PixelList(1,1);
            lastx=test.PixelList(length(test.PixelList),1);
            totalx=lastx-firstx;
            gut=regionprops(imbw,'Orientation');
            or=gut.Orientation-st_angle;
            
            if or>threshold_snap_pos
                analyze_worm=1;
            elseif or<threshold_snap_pos&&gut.Orientation-st_angle>threshold_snap_neg
                analyze_worm=2; %re-analyze worm after cooling
            else
                analyze_worm=0;
            end
        end
    end
    
    if analysis_step==2

        if ecc<threshold_eccentricity
            analyze_worm=0;
            or=0;
        else
            % GUT FROM SNAPSHOT
            imbw=im2bw(J,level*1.5);
            se=strel('disk',10);
            imbw = imclose(imbw,se);
            test=regionprops(imbw,'Area','PixelIdxList','MajorAxisLength');
            areas=[];axis_length=[];pospixels=[];
            for k=1:length(test)
                areas(k)=test(k).Area;
                axis_length(k)=test(k).MajorAxisLength;
            end
            imbw=zeros(size(imbw));
            [t tt]=max(axis_length);
            pospixels=test(tt).PixelIdxList;
            imbw(pospixels)=1;
            test=regionprops(imbw,'PixelList');
            firstx=test.PixelList(1,1);
            lastx=test.PixelList(length(test.PixelList),1);
            totalx=lastx-firstx;
            gut=regionprops(imbw,'Orientation');
            or=gut.Orientation-st_angle;
            if or>threshold_stack_pos
                analyze_worm=1;
            else
                analyze_worm=0;
            end
        end
    end
    