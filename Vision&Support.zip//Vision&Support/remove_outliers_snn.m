function [bw_l no]=remove_outliers_snn(bw_l)    

stats=regionprops(bw_l,'PixelIdxList','Centroid');
no=0;



    if length(stats)>=6%&&length(stats)<25
        points=length(stats);
        for k=1:points
            coor_for_p(k,:)=stats(k).Centroid;
            pixels(k).px=stats(k).PixelIdxList;
        end
       
        meany=mean(coor_for_p(:,2));
        diffy=abs(coor_for_p(:,2)-meany);
        [B Ix]=sort(diffy);
        n=round(length(stats)*2/3);
     
        p=polyfit(coor_for_p(Ix(1:n),1),coor_for_p(Ix(1:n),2),1);
       
        y=polyval(p,coor_for_p(:,1));
        res=abs((y-coor_for_p(:,2)));
%         th=sum(res.^2)/length(res);
        a=find(abs(res)>40);
       
        for i=length(a):-1:1
            no=no+1;
            erase_pixels=pixels(a(i)).px;
            bw_l(erase_pixels)=0;
            stats(a(i))=[];
        end   
        
        coor_for_p=[];pixels=[];
        points=round(length(stats)/2);

        left=round((length(stats)-points))-2;
        if left<=0
            left=1;
        end
%         kk=left;
        for k=left:length(stats)
            coor_for_p(k,:)=stats(round(k)).Centroid;
            pixels(k).px=stats(round(k)).PixelIdxList;
        end
        coor_for_p(1:left-1,:)=[];
        pixels(1:left-1)=[];

        p=polyfit(coor_for_p(1:end,1),coor_for_p(1:end,2),1);
        y=polyval(p,coor_for_p(:,1));
        res=abs((y-coor_for_p(:,2)));
        a=find(abs(res)>20);
        for i=length(a):-1:1
            no=no+1;
            erase_pixels=pixels(a(i)).px;
            bw_l(erase_pixels)=0;
            stats(a(i))=[];
        end   
        
%         figure;imshow(bw_l);
%     elseif length(stats)>=25
%         coor_for_p=[]; pixels=[];
%         points=round(length(stats)/2);
%         for k=1:points
%             coor_for_p(k,:)=stats(round(k)).Centroid;
%             pixels(k).px=stats(round(k)).PixelIdxList;
%         end
%         p=polyfit(coor_for_p(2:end,1),coor_for_p(2:end,2),1);
%         y=polyval(p,coor_for_p(:,1));
%         res=(y-coor_for_p(:,2));
%         th=sum(res.^2)/length(res);
%         a=find(abs(res)>40);
%         for i=1:length(a)
%             no=no+1;
%             erase_pixels=pixels(a(i)).px;
%             bw_l(erase_pixels)=0;
%         end
%         
%         coor_for_p=[]; pixels=[]; l=1;
%         for k=points+1:length(stats)
%             coor_for_p(l,:)=stats(round(k)).Centroid;
%             pixels(l).px=stats(round(k)).PixelIdxList;
%             l=l+1;
%         end
%         p=polyfit(coor_for_p(1:end-1,1),coor_for_p(1:end-1,2),1);
%         y=polyval(p,coor_for_p(:,1));
%         res=(y-coor_for_p(:,2));
%         th=sum(res.^2)/length(res);
%         a=find(abs(res)>40);
%         for i=1:length(a)
%             no=no+1;
%             erase_pixels=pixels(a(i)).px;
%             bw_l(erase_pixels)=0;
        end
    end
    

% end