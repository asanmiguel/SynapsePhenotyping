function features =HTFeaturesCreate(max_image)
%
% Description: 	This creates the features that will eventually be used to classify the
%               animal as being Head or Tail oriented. 

% Parameters:   image - an image of a single focal plane acquired with the
%               dualview. Contains red and green channels
%               corr_offset - the offset between the two images so the red and green
%               channels can be aligned.
% Returns:      features - vector containing features describing the image
% 
max_image=double(max_image);
im_green=max_image(1:size(max_image,1)/2,:); %green
im_temp=im_green;
mean_temp=mean2(im_temp(im_temp~=Inf));
im_temp(im_green==0)=mean_temp;
im_temp(im_green==Inf)=mean_temp;
im_temp(isnan(im_green))=mean_temp;
im_green=im_temp;
im_red=max_image(size(max_image,1)/2+1:end,:); %red
% im_temp=im_red;
% mean_temp=mean2(im_temp(im_temp~=Inf));
% im_temp(im_red==0)=mean_temp;
% im_temp(im_red==Inf)=mean_temp;
% im_temp(isnan(im_red))=mean_temp;
% im_green=im_red;
% im_ratio=im_green./im_red; %ratio

bitdepth=2^12-1;

features=[];
green_bins=0:bitdepth/15:bitdepth;
% red_bins=0:bitdepth/15:bitdepth;
% ratio_bins=0:1/15:2;
% numpix=size(im_green,1)*size(im_green,2);
% nbin=0:1/15:1;
% images(1).im=im_green;
% images(1).bins=green_bins;
% images(2).im=im_red;
% images(2).bins=red_bins;
% images(3).im=im_ratio;
% images(3).bins=ratio_bins;
   
    %%%%%GREEEEN
    t=histc(im_green(:),green_bins);
    features(1,end+1:end+length(t))=t;
    features(1,end+1)=mean2(im_green);
    features(1,end+1)=std(double(im_green(:)));
    features(1,end+1)=median(im_green(:));
    features(1,end+1)=max(im_green(:));
    features(1,end+1)=min(im_green(:));
    features(1,end+1)=sum(im_green(:)>=max(im_green(:)));
    features(1,end+1)=sum(im_green(:)>=mean(im_green(:)));
    features(1,end+1)=sum(im_green(:)>=(mean(im_green(:)+std(double(im_green(:))))));
    temp=graycomatrix(im_green,'GrayLimits',[0 bitdepth]);
    temp2=graycoprops(temp);
    features(1,end+1)=temp2.Contrast;
%     features(1,end+1)=temp2.Correlation;
    features(1,end+1)=temp2.Energy;
    features(1,end+1)=temp2.Homogeneity;

    %%%%%RED
    t=histc(im_red(:),green_bins);
    features(1,end+1:end+length(t))=t;
    features(1,end+1)=mean2(im_red);
    features(1,end+1)=std(double(im_red(:)));
    features(1,end+1)=median(im_red(:));
    features(1,end+1)=max(im_red(:));
    features(1,end+1)=min(im_red(:));
    features(1,end+1)=sum(im_red(:)>=max(im_red(:)));
    features(1,end+1)=sum(im_red(:)>=mean(im_red(:)));
    features(1,end+1)=sum(im_red(:)>=(mean(im_red(:)+std(double(im_red(:))))));
    temp=graycomatrix(im_red,'GrayLimits',[0 bitdepth]);
    temp2=graycoprops(temp);
    features(1,end+1)=temp2.Contrast;
%     features(1,end+1)=temp2.Correlation;
    features(1,end+1)=temp2.Energy;
    features(1,end+1)=temp2.Homogeneity;
