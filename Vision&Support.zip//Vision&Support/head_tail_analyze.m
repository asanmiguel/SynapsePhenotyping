function [predict_label_kernel dec_values_kernel]=head_tail_analyze(image,modeltype,cHTParameters)

    gb_features=HTFeaturesCreate(image);
    gb_features=(gb_features - repmat(cHTParameters.Min,size(gb_features,1),1));
    gb_features=gb_features*spdiags(1./(cHTParameters.Max-cHTParameters.Min)',0,size(gb_features,2),size(gb_features,2));
    [predict_label_kernel, accuracy, dec_values_kernel] = svmpredict(ones(size(gb_features,1),1), gb_features, cHTParameters.HTKernel);

    if dec_values_kernel<0.02
        predict_label_kernel=2;
    end

end

