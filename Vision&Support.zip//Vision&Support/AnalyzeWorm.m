function [IsWildType phenotyped reason bw_l syn_mean no]=AnalyzeWorm(image_pixel,predict_image)

thr1l=4.0;    
thr1h=13;
thr2l=4.5; %4.5
thr2h=14;
thr3l=0;    thr3h=1000;%inactive(moment)
thr4l=5;    thr4h=100;%Max<40
thr5l=-1.5;   thr5h=50; %%inactive
thr6l=0;    
thr6h=0.8; %0.75
thr7l=0;    thr7h=1100;

filled=imfill(predict_image,'holes');
bw_l=bwlabel(filled,4);
bw_l=logical(bw_l);

%%%REMOVE OUTLIERS
[bw_l no]=remove_outliers_s(bw_l);
bw_l=logical(bw_l);
allstats=regionprops(bw_l,image_pixel(1:480,:),'Area','Centroid');

CH=bwconvhull(bw_l);
props=regionprops(CH,'Eccentricity','Area','BoundingBox','MajorAxisLength','MinorAxisLength');

if ~isempty(props)
    axisratio=props.MinorAxisLength/props.MajorAxisLength;
else
    axisratio=0;
end

if length(allstats)>=8&&props.Area<50000&&axisratio<0.1
    x=[allstats(:).Area];
    x(x==0)=NaN;
    s=isnan(x);
    xr=x(~s);
    xr_above1=xr(xr>1);
    if isempty(xr_above1)
        xr_above1=0;
    end
    xr_below40=xr(xr<40);
    syn_mean=mean(xr,2);%1
    syn_mean_above1=mean(xr_above1,2);%2
    syn_moment_above1=moment(xr_above1,2);%3
    syn_max_below40=max(xr_below40(:));%4
    syn_num_above8=sum(xr>8);
    syn_percent_below6=sum(xr<6)/sum(xr>0);
    first=allstats(1).Centroid;
    last=allstats(end).Centroid;
    syn_distance=(sum((last-first).^2))^0.5;
    mutant=syn_mean<thr1l|syn_mean>thr1h|...
           syn_mean_above1<thr2l|syn_mean_above1>thr2h|...
           syn_moment_above1<thr3l|syn_moment_above1>thr3h|...
           syn_max_below40<thr4l|syn_max_below40>thr4h|...
           syn_num_above8<thr5l|syn_num_above8>thr5h|...
           syn_percent_below6<thr6l|syn_percent_below6>thr6h|...
           syn_distance<thr7l|syn_distance>thr7h;
    if mutant
        if syn_mean<thr1l|syn_mean>thr1h
            reason=strcat('Mean= ',int2str(syn_mean));
        elseif syn_mean_above1<thr2l|syn_mean_above1>thr2h
            reason=strcat('Mean>1= ',int2str(syn_mean_above1));
        elseif syn_moment_above1<thr3l|syn_moment_above1>thr3h
            reason=strcat('Moment>1= ',int2str(syn_moment_above1));
        elseif syn_max_below40<thr4l|syn_max_below40>thr4h
            reason=strcat('Max_below40= ',int2str(syn_max_below40));
        elseif syn_num_above8<thr5l|syn_num_above8>thr5h
            reason=strcat('#>8= ',int2str(syn_num_above8));
        elseif syn_percent_below6<thr6l|syn_percent_below6>thr6h
            reason=strcat('%<6=',int2str(syn_percent_below6));
        elseif syn_distance<thr7l|syn_distance>thr7h
            reason=strcat('Distance',int2str(syn_distance));
        end
    else
        reason=' ';
    end
    IsWildType=~mutant;
    phenotyped=true;
else
    IsWildType=true;
    phenotyped=false;
    syn_mean=0;
    reason=' ';
    if length(allstats)<8
        reason=strcat('Only ',int2str(length(allstats)),' found');
    elseif props.Area>=50000
        reason=strcat('Area larger than 50000');
    elseif axisratio<=0.1
        reason=strcat('Axis ratio < 0.1');
    else
        reason=' ';
    end
end
     
     
     
