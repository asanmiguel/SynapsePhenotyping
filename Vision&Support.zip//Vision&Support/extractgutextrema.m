function left_px=extractgutextrema(img,predict_label) 

    img=double(mat2gray(img));
    predict_label=logical(predict_label);
    se=strel('rectangle',[20 20]);
    predict_label=imdilate(predict_label,se);
    img(predict_label)=quantile(img(:),0.65);
    level=graythresh(mat2gray(img));
    imbw=im2bw(mat2gray(img),level*1.25);
    imbw=bwareaopen(imbw,200);
    test=regionprops(imbw,'Area','PixelIdxList','Extrema','PixelList');
    areas=[];axis_length=[];pospixels=[];

    for k=1:length(test)
        areas(k)=test(k).Area;
        [min_x(k) minind]=min(test(k).PixelList(:,1));
        min_y(k)=test(k).Extrema(minind,2);
    end
    if length(test)>1
        te=(min_y==1);
        min_y(te)=[];
        min_x(te)=[];
    end
    left_px=min(min_x);     
end         