function [feat_v feat_ai]=phenotypicfeatures_n(allstats)

    x=[allstats.stats(:).Area];
    s=isnan(x);
        xr=x(~s);
        xr_above1=xr(xr>1);
    xr_above2=xr(xr>2);
    xr_sorted=sort(xr);
    xfa=xr_above1(xr_above1<max(xr_above1)&xr_above1>min(xr_above1));
    y=[allstats.stats(:).MeanIntensity];
    intfa_all=y;
    intfa=y(xr_above1<max(xr_above1)&xr_above1>min(xr_above1));

    y(x==0)=NaN;
    x(x==0)=NaN;
    intint=x.*y;
    int=y;
  
    if isempty(xr_above2)
        xr_above2=0;
    end
    if isempty(xr_above1)
        xr_above1=0;
    end
    
    %%for total integrated intensity
    tintb=0;
    for j=1:length(allstats.stats)
        tinta=[];
        tinta=allstats.stats(j).PixelValues;
        tintb=tintb+sum(tinta);
    end
            
    %%GENERAL
        feat_v(1)=length(xr_above1);
        feat_v(2)=mean(xr,2);
        feat_v(3)=mean(xr_above1,2);
        feat_v(4)=moment(xr_above1,2)/(mean(xr_above1,2)^2);
        feat_v(5)=sum(xr>8);
        feat_v(6)=sum(xr<6)/sum(xr>0);
        feat_v(7)=sum(xr_above1<8)/sum(xr_above1);
        feat_v(8)=std(xr)/mean(xr);
        feat_v(9)=quantile(xr,0.25);
        feat_v(10)=median(xr);
        feat_v(11)=quantile(xr,0.75);
        feat_v(12)=prctile(xr,90);
        feat_v(13)=max(xr);
        feat_v(14)=mean(xr_sorted(1:round(length(xr_sorted)/2)));
        feat_v(15)=std(xr_sorted(1:round(length(xr_sorted)/2)))/feat_v(14);
        feat_v(16)=mean(xr_sorted(round(length(xr_sorted)/2)+1:length(xr_sorted)));
        feat_v(17)=std(xr_sorted(round(length(xr_sorted)/2)+1:length(xr_sorted)))/feat_v(16);
        feat_v(18)=prctile(xr,90)/quantile(xr,0.25);
        feat_v(19)=feat_v(16)/feat_v(14);
               
        feat_v(20)=mean(int);
        feat_v(21)=std(int)/mean(int);
        
        feat_v(22)=mean(intint);
        feat_v(23)=std(intint)/mean(intint);
        feat_v(24)=moment(intint,2)/((mean(intint))^2);
        feat_v(25)=min(intint);
        feat_v(26)=quantile(intint,0.25);
        feat_v(27)=median(intint);
        feat_v(28)=quantile(intint,0.75);
        feat_v(29)=prctile(intint,90);
        feat_v(30)=max(intint);
        feat_v(31)=mean(intint(1:round(length(intint)/3)));
        feat_v(32)=mean(intint(round(length(intint)/3)+1:round(length(intint)*2/3)));
        feat_v(33)=mean(intint(round(length(intint)*2/3)+1:end));
        feat_v(34)=feat_v(33)/feat_v(31);
        feat_v(35)=feat_v(33)/feat_v(32);
        feat_v(36)=feat_v(32)/feat_v(31);
       
        cent=[];d=[];
        for m=1:length(allstats.stats)
            cent(m,1:2)=round(allstats.stats(m).Centroid);
            cent(m,3)=allstats.stats(m).Area;
        end
        
        first=cent(1,1:2);
        last=cent(m,1:2);
        syn_distance=(sum((last-first).^2))^0.5;
        
        max_ofall=max(xr);
        d=allstats.d(:);
        d_above3=d(d>3);
        feat_v(37)=sum(d_above3(1:end));
        feat_v(38)=mean(d_above3(:));
        feat_v(39)=std(d_above3)/mean(d_above3);
        feat_v(40)=mean(d_above3(1:round(length(d_above3)/2)));
        feat_v(41)=std(d_above3(1:round(length(d_above3)/2)))/mean(d_above3(1:round(length(d_above3)/2)));
        feat_v(42)=mean(d_above3(round(length(d_above3)/2)+1:end));
        feat_v(43)=std(d_above3(round(length(d_above3)/2)+1:end))/mean(d_above3(round(length(d_above3)/2)+1:end));
        feat_v(44)=prctile(d,90);
        feat_v(45)=length(xr_above1)/feat_v(37);
        
        
        bins(1:8)=0:5:35;
        bins(9)=inf;
        all=histc(xr,bins)/length(xr);
        feat_v(46:48)=all(1:3);
        bins=[];
        bins(1:3)=0:1000:2000;
        bins(4)=inf;
        all=histc(int,bins)/length(xr);
        bins=[];
        bins(1:3)=0:10000:20000;
        bins(4)=inf;
        all=histc(intint,bins)/length(xr);
        feat_v(49)=prctile(d,95);
        feat_v(50)=prctile(d,75);
        feat_v(51)=allstats.left_syn_px(1)-allstats.leftpx;
        feat_v(52)=mean2(allstats.int);
        feat_v(53)=std(allstats.int(:))/mean2(allstats.int);
        feat_v(54)=prctile(xr,10);
        feat_v(55)=prctile(intint,10);

        zc=[];
        for i=1:length(allstats.stats)
            z=allstats.stats(i).PixelValues;
            zc=cat(1,zc,z);
        end
        zc=double(zc);
        bins=[];
        bins(1:10)=0:500:4500;
        bins(11)=inf;
        all=histc(zc,bins)/length(zc);
        feat_v(56:62)=all(2:8);
        feat_v(63)=range(zc);
        feat_v(64)=std(zc)/mean(zc);
        zcm=zc-min(zc);
        feat_v(65)=quantile(zcm,0.25);
        feat_v(66)=quantile(zcm,0.5);
        feat_v(67)=quantile(zcm,0.75);
        feat_v(68)=quantile(zcm,0.9);
        thr1=range(zcm)*0.1;
        thr2=range(zcm)*0.25;
        thr3=range(zcm)*0.5;
        thr4=range(zcm)*0.75;
        thr5=range(zcm)*0.9;
        thr6=range(zcm)*0.95;
        feat_v(69)=sum(zcm<thr1)/length(zcm);
        feat_v(70)=(sum(zcm<thr2)-sum(zcm<thr1))/length(zcm);
        feat_v(71)=(sum(zcm<thr3)-sum(zcm<thr2))/length(zcm);
        feat_v(72)=(sum(zcm<thr4)-sum(zcm<thr3))/length(zcm);
        feat_v(73)=(sum(zcm<thr5)-sum(zcm<thr4))/length(zcm);
        feat_v(74)=(sum(zcm<thr6)-sum(zcm<thr5))/length(zcm);
        temp2=sum(xr>0.25*range(xr));
        feat_v(75)=temp2;
        %%%TOTAL INTEGRATED INTENSITY
        feat_v(76)=tintb;
        
        
        %%% FOR ARTIFICIAL IMAGE
        [xfa idx]=sort(xfa);
        intfans=intfa;
        intfa=intfans(idx);
        numpq=round((length(xfa)/4));
        miss=length(xfa)-numpq*4;
        qnum1=numpq+miss;
        qnum2=numpq;
        feat_ai(1)=feat_v(37);
        feat_ai(2)=max_ofall;
        feat_ai(3)=min(xr_above1);
        feat_ai(4)=max(xr_above1);
        feat_ai(5)=mean(xfa(1:qnum1));
        feat_ai(6)=mean(xfa(qnum1+1:qnum1+qnum2));
        feat_ai(7)=mean(xfa(qnum1+qnum2+1:qnum1+2*qnum2));
        feat_ai(8)=mean(xfa(qnum1+2*qnum2+1:qnum1+3*qnum2));
        
        feat_ai(9)=mean(intfa_all(xr==1));
        feat_ai(10)=mean(intfa_all(xr==max(xr)));
        feat_ai(11)=mean(intfa_all(xr==min(xr_above1)));
        
        feat_ai(12)=mean(intfa(1:qnum1));
        feat_ai(13)=mean(intfa(qnum1+1:qnum1+qnum2));
        feat_ai(14)=mean(intfa(qnum1+qnum2+1:qnum1+2*qnum2));
        feat_ai(15)=mean(intfa(qnum1+2*qnum2+1:qnum1+3*qnum2));
        
        feat_ai(16)=feat_v(1);
        feat_ai(17)=feat_v(51);
        feat_ai(18)=length(xr);
        

    
