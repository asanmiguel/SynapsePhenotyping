function [predict_image,dec_image,dec_image_lin]=pixel_analyzelin(image_pixel,modeltype,cPixelTraining)

if modeltype==1 %feature creation specific to WyIs85
    filtered_image=create_features_n(image_pixel);
elseif modeltype==2 %feature creation specific to WyIs292 (green channel)
    filtered_image=create_features_greenchannelonly(image_pixel);
elseif modeltype==3 %features specific to red channel only
    filtered_image=create_features_redchannelonly(image_pixel);
end
filtered_image=(filtered_image - repmat(cPixelTraining.Pixel_Min,size(filtered_image,1),1));
filtered_image=filtered_image*spdiags(1./(cPixelTraining.Pixel_Max-cPixelTraining.Pixel_Min)',0,size(filtered_image,2),size(filtered_image,2));
[predict_label, accuracy, dec_values] = predict(ones(size(sparse(filtered_image),1),1), sparse(filtered_image), cPixelTraining.PixelModel); % test the training data]\
predict_image=reshape(predict_label,[size(image_pixel,1)/2 size(image_pixel,2)]);
% predict_image=reshape(predict_label,[size(image_pixel,1) size(image_pixel,2)]);

dec_image=accuracy;
dec_image_lin=reshape(dec_values,[size(image_pixel,1)/2 size(image_pixel,2)]);

