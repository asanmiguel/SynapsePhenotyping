function [int d leftpx]=extractintpctlint_nn(img,predict_label) 
    predict_label=logical(predict_label);
    centroids_p=regionprops(predict_label,'Centroid','Area');
    
    centroids=[];
    for i=1:length(centroids_p)
        centroids(i,:)=round(centroids_p(i).Centroid);
        areas(i)=centroids_p(i).Area;
    end
        connected_dots=zeros(480,1280);
      
        for  j=1:length(centroids)-1
        point1=centroids(j,:);
        allpoints=point1;
        point2=centroids(j+1,:);
        b=1;
       
        while b~=0
            x0=point1(1);
            y0=point1(2);
            neighbors=[x0-1,y0-1;x0,y0-1;x0+1,y0-1;...
                x0-1,y0;x0+1,y0;...
                x0-1,y0+1;x0,y0+1;x0+1,y0+1];
           for k=1:8
               ndist(k)=pdist(vertcat(neighbors(k,:),point2));
           end
           [b idx]=min(ndist);

           point1=neighbors(idx,:);
           allpoints=vertcat(allpoints,point1);
        end
       
        linearInd = sub2ind([480 1280], allpoints(:,2), allpoints(:,1));
        zer(linearInd)=1;
        zer(predict_label)=0;
        linInd=find(zer);

        d(j)=pdist(centroids(j:j+1,:));
        int(j)=mean2(img(linInd));
        connected_dots(linearInd)=1; 
        end

    a=areas==1;
    centroids(a,:)=[];
        [r minind]=min(centroids(:,1));
    leftpx=centroids(minind,:);

end