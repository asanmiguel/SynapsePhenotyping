function [time_elapsed rgiZStackImage] = GetZStackPiezo(CDevices,CCam,CStageSettings)

tic
CStageSettings.uiStepSize=CStageSettings.uiStepSize*10;


uiZTravelDistance = CStageSettings.uiZHeight*10; 
uiFocalPlanesNumber = CStageSettings.uiZHeight;
strZTravelDistance = num2str(uiZTravelDistance);

fprintf(CDevices.pSerial,strcat('R Z=-',strZTravelDistance));
fscanf(CDevices.pSerial);
fprintf(CDevices.pSerial,'/');
fscanf(CDevices.pSerial)
iWidth = 1280;
iHeight = 480;
rgiZStackImage=uint16(zeros(iHeight*2,iWidth,uiFocalPlanesNumber));

uiZTravelDistance = CStageSettings.uiStepSize;
strZTravelDistance = num2str(uiZTravelDistance);
k=0;
for i=1:uiFocalPlanesNumber
    rgiZStackImage(1:480,:,i)= getsnapshot(CCam.pCam1);
    rgiZStackImage(481:end,:,i)= getsnapshot(CCam.pCam2);
    fprintf(CDevices.pSerial,strcat('R Z=',strZTravelDistance));
    fscanf(CDevices.pSerial);

    k=k+uiZTravelDistance;

end

% %% Zero Stage Position
% % Zero the stage position and read serial port to clear RX buffer
% % uiZTravelDistance = uiFocalPlanesNumber*CStageSettings.uiStepSize-floor(uiFocalPlanesNumber/2*CStageSettings.uiStepSize);  
% uiZTravelDistance = floor(CStageSettings.uiZHeight*CStageSettings.uiStepSize)-uiFocalPlanesNumber*CStageSettings.uiStepSize;  
% 
% strZTravelDistance = strcat('71024 +',int2str(uiZTravelDistance));  % create command string to be sent to stage through serial port
% fprintf(CDevices.pSerial,strZTravelDistance);
% fscanf(CDevices.pSerial);
fprintf(CDevices.pSerial,'W Z')
fscanf(CDevices.pSerial)
time_elapsed=k;
toc;
