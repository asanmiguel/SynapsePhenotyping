  
clear
close all
[filename, pathname] = uigetfile('*.mat', 'Pick the mat file containing the synapse classifier');
load(fullfile(pathname,filename));
% Provide path to folder where images are located
directory_name='';
z=dir(fullfile(directory_name,'*.tif'));

addpath Vision&Support
%%
allstats=struct([]);
for i=1:length(z)
    disp(sprintf('Worm %d', i))

    max_image=imread(fullfile(directory_name,z(i).name));
    [analyze_worm,or,ecc]=analyze_wormorientation(max_image(1:480,:),1,0);
    if ecc>=0.45
        predict_image=pixel_analyzelin(max_image,cPixelTraining);
        filled=imfill(predict_image,'holes');
        bw_l=bwlabel(filled,4);
        bw_l=logical(bw_l);
        max_image=max_image-min(max_image(:));
        [bw_l no1]=remove_outliers_s(bw_l);
        [bw_l no2]=remove_outliers_snn(bw_l);
        allstats(i).stats(:)=regionprops(bw_l,max_image(1:480,:),'all');
        num(i)=length(allstats(i).stats);
        allstats(i).outliers=no1+no2;
        
        left_px=extractgutextrema(max_image,bw_l);
        
         allstats(i).leftpx=left_px;
        if length(allstats(i).stats)<=3
            allstats(i).left_syn_px=NaN;
            allstats(i).int=NaN;
            allstats(i).d=NaN;
            allstats(i).left_syn_px=NaN;
        else
            [allstats(i).int allstats(i).d allstats(i).left_syn_px]=extractintpctlint_nn(max_image,bw_l);
        end 
    else
        allstats(i).left_syn_px=NaN;
        allstats(i).int=NaN;
        allstats(i).d=NaN;
        allstats(i).stats=[];
    end
end
beep
all=extractpopulationfeatures(allstats);



